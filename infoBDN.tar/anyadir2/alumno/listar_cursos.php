<?php
require '../functions/functions.php';
session_start();
if(isset($_SESSION['rol']) && $_SESSION['tipo'] == "alumno"){
    echo $_SESSION['rol'];
$conexion = conectar();
$usuario = $_SESSION['rol'];
$buscador = $_POST['buscar'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" type="text/css" href="../css/prueba.css">

    <title>Document</title>
</head>
<body>
<div class="parent">
<div class="div1"> </div>
<div class="div2"><img src="../img/cursos.png" alt="Girl in a jacket"></div>
<div class="div3"><nav>
<a href="dashboard_alumno.php">Volver atras</a><br>
</div>
<div class="div4"> <form name ="busqueda" method="post">buscar <input type="text" name="buscar">
           ENVIAR <input type="submit">REINICIAR BUSCADOR <input type="submit">
           
           <?php $listar_cursos = ver_cursos_disponibles($conexion,$buscador,$usuario);?>
           <!--?php $dashboard_alumno = dashboard_alumno($conexion,$buscar,$usuario);?>-->
</form></div>
<div class="div5">
<a href="cerrar_sesion.php">Cerrar sesion</a></div>
<div class="div6"> COPYRIGHT CURSOS ESPAÑA</div>
</div> 
</body>
</html>

<?php
}else{
    echo "No estas validado!";
}
?>