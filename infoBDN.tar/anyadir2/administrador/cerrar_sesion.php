<?php
session_start();
session_destroy();
echo "Sesion cerrada cone exito!";
echo "<meta http-equiv='refresh' content='3;url=../index.php'>";
?>