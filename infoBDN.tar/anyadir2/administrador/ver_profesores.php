<?php
require '../functions/functions.php';
session_start();
if(isset($_SESSION['rol']) && $_SESSION['tipo'] == "administrador"){
    echo $_SESSION['rol'];
$conexion = conectar();
$buscar = $_POST['buscar'];
//llamada = ver_profesor($conexion);
?>  
<?php

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/prueba.css">
    <title>Document</title>
</head>
<body>

<div class="parent">
<div class="div1"> </div>
<div class="div2">  <img src="../img/cursos.png" alt="Girl in a jacket"> </div>
<div class="div3"><nav>
    <a href="dashboard_administrador.php">Volver atras</a><br>
    <a href="creacion_cursos.php">Crear un curso</a><br>
    <a href="creacion_profesores.php">Crear un profesor</a><br>
    <a href="ver_alumnos.php">Ver listado de alumnos</a><br>
    <a href="ver_curso.php">Ver listado de cursos</a><br>
</div>
<div class="div4"><form name ="busqueda" method="post">buscar <input type="text" name="buscar">
  LIMPIAR <input type="submit">
           ENVIAR <input type="submit"><?php $ver_profesor = ver_profesor($conexion,$buscar);?></form> </div>
<div class="div5"> <a href="cerrar_sesion.php">Cerrar sesion</a></div>
<div class="div6"> COPYRIGHT CURSOS ESPAÑA</div></div> 
</body>
</html>
<?php
}else{
    echo "No estas validado";
}