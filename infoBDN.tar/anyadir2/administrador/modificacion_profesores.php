<?php
require '../functions/functions.php';
session_start();
if(isset($_SESSION['rol']) && $_SESSION['tipo'] == "administrador"){
    $con = conectar();
    $dni = $_GET['DNI'];
    $ver_profesor = ver_profesores($con,$dni);
    if ($_POST){
        $nombre = $_POST['nombre'];
        $apellido  = $_POST ['apellidos'];
        $t_academico = $_POST['t_academico'];
        $contrasenya = $_POST['contrasenya'];
        $dni = $_POST['dni'];
        $modificar_profesor   = modificar_profesor($con,$nombre,$apellido,$t_academico,$contrasenya,$dni);
        //$foto = $_POST['foto'];
       echo "<meta http-equiv='refresh' content='3;url=ver_profesores.php'>";
    }
    else{
    ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <link rel="stylesheet" type="text/css" href="../css/prueba.css">
            <title>Document</title>
        </head>
        <body>
        <div class="parent">
<div class="div1"> </div>
<div class="div2">  <img src="../img/cursos.png" alt="Girl in a jacket"> </div>
<div class="div3"><nav>
<a href="dashboard_administrador.php">Volver atras</a><br>
    <a href="creacion_cursos.php">Crear un curso</a><br>
    <a href="creacion_profesores.php">Crear un profesor</a><br>
    <a href="ver_alumnos.php">Ver listado de alumnos</a><br>
    <a href="ver_curso.php">Ver listado de cursos</a><br>
    <a href="ver_profesores.php">Ver listado de profesores</a><br>
</div>
<div class="div4"> <form method="post" action="modificacion_profesores.php" method="POST">
    DNI <input type ="text"  readonly name="dni" value="<?php echo $ver_profesor['DNI'];?>"><br>
    APELLIDOS <input type ="text" required name="apellidos" value="<?php echo $ver_profesor['APELLIDOS'];?>"><br>
    T_ACADEMICO <input type="text"  required name ="t_academico" value="<?php echo $ver_profesor['T_ACADEMICO'];?>"><br> 
    CONTRASENYA <input type="text"  required name="contrasenya"value="<?php echo $ver_profesor['CONTRASENYA'];?>"><br> 
    FOTO <input type="text" name="foto" required value="<?php echo $ver_profesor['FOTO'];?>"><br> 
    Nombre <input type="text" name="nombre" required value="<?php echo $ver_profesor['NOMBRE'];?>"><br>
    EDITAR CAMPO(S) <input type="submit"><br>
        </form> </div>
<div class="div5"> <a href="cerrar_sesion.php">Cerrar sesion</a></div>
<div class="div6"> COPYRIGHT CURSOS ESPAÑA</div></div> 
            </body>
            </html>
 
    <?php
    }
}else{
        echo "Usuario no validado, redirigiengo a la página del login";
        echo "<meta http-equiv='refresh' content='3;url=admin.php'>";
 }   

?>
 <?php
 /*
    while($fila=mysqli_fetch_array($ver_profesor)){
           echo "<option value='".$fila['NOMBRE']."'>".$fila['NOMBRE']."</option>";
        }
    echo "</select>"; ?><br>
    ?>*/