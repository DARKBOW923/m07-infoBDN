<?php
session_start();
//echo $test['CONTRASENYA'];
if(isset($_SESSION['rol']) && $_SESSION['rol'] == "administrador"){
    require '../functions/functions.php';
$con = conectar();
$dni = $_GET['DNI'];
echo $dni;
$borrar = eliminar_profesor($con, $dni);
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
    </head>
    <body>
        
    <p> Alumno borrado con exito! Redirigiendo en pocos segundos..</p>
    <meta http-equiv='refresh' content='3;url=ver_profesores.php'>
    </body>
    </html>
    <?php
}else{
    echo "No validado";
    echo "<meta http-equiv='refresh' content='3;url=admin.php'>";
}