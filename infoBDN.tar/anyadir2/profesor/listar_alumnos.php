<?php
session_start();
require '../functions/functions.php';
if(isset($_SESSION['rol']) && $_SESSION['tipo'] == "profesor"){
$usuario= $_SESSION['rol'];
$id_curso = $_GET['ID_CURSO'];
$con = conectar();
//$ver_todo =listar_cursos_alumnos_impartidos($con,$usuario,$id_curso);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/prueba.css">
    <title>Document</title>
</head>
<body>
<div class="parent">
<div class="div1"> </div>
<div class="div2"><img src="../img/cursos.png" alt="Girl in a jacket"></div>
<div class="div3"><nav>
    <a href="dashboard_profesor.php">Volver atras</a><br>

</div>
<div class="div4"> <?php dashboard_profesor($con,$usuario);?>
</div>
<div class="div5"> <a href="cerrar_sesion.php">Cerrar sesion</a></div>
<div class="div6"> </div>
</div>
</body>
</html>







<?php

}else{
    echo ("No estás validado.");
}
?>