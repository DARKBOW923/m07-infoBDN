<?php
require 'functions/functions.php';
session_start();
if ($_POST){
        $user =$_POST['user'];
        $pass = $_POST['pass'];
        $con = conectar();
        //echo $con;
        $query_successful = iniciar_sesion_administrador($con, $user, $pass);
        if ($query_successful){
             $_SESSION['rol']=$user;
             $_SESSION['tipo'] ="administrador";
             echo "Usuario encontrado!";
             echo $query_sucessful;
             echo "<meta http-equiv='refresh' content='3;url=administrador/dashboard_administrador.php'>";
            }
        else{
            echo "usuario no encontrado o inexistente";
            echo $query_successful;
            echo "<meta http-equiv='refresh' content='3;url=../admin.php'>";
        }
        }else{
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/iniciar_sesion.css">
    <title>Document</title>
    </head>
    <body>
    <div class="parent">
    <div class="div1"></div>
    <div class="div2"><img src="img/cursos.png" alt="logo" width="1575" height="300"></div>
    <div class="div3">COPYRIGHT CURSOS ESPAÑA</div>
    <div class="div4"><form method="post" action ="admin.php">
        Usuario:<input type ="text" name="user">
        Contrasenya:<input type ="password" name="pass">
        <input type="submit" action ="admin.php"></input>
    </form> </div>
    <div class="div5"> </div>
    <div class="div6"></div>
    </div> 
    </body>
    </html>

<?php


}
?>