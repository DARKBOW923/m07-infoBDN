<?php
require '../functions/functions.php';
session_start();
if(isset($_SESSION['rol']) && $_SESSION['tipo'] == "administrador"){
    $con = conectar();
    if ($_POST){
        echo $_SESSION['tipo'];

        $dni =$_POST["dni"];
        $nombre =$_POST["nombre"];
        $apellido =$_POST["apellido"];
        $foto=$_POST["foto"];
        $t_academico=$_POST["t_academico"];
        $contrasenya=$_POST["contrasenya"];
        
       /* $FECHA_ACTUAL = date("d-m-Y");
        $FECHA_RESULTADO =  strtotime($FECHA_ACTUAL);
        $FECHA_DUMP_INICIO = strtotime($F_INICIO);
        $FECHA_DUMP_FINAL = strtotime($F_FINAL);*/
            echo "<meta http-equiv='refresh' content='3;url=ver_profesores.php'>";
            $crear_curso = creacion_profesor($con,$dni,$nombre,$foto,$t_academico,$contrasenya,$apellido);
    
    }else{
    ?>
  <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <link rel="stylesheet" type="text/css" href="../css/prueba.css">
            <title>Document</title>
        </head>
        <body>
        <div class="parent">
<div class="div1"> </div>
<div class="div2">  <img src="../img/cursos.png" alt="Girl in a jacket"> </div>
<div class="div3"><nav>
    <a href="dashboard_administrador.php">Volver atras</a><br>
    <a href="creacion_cursos.php">Crear un curso</a><br>
    <a href="ver_alumnos.php">Ver listado de alumnos</a><br>
    <a href="ver_curso.php">Ver listado de cursos</a><br>
    <a href="ver_profesores.php">Ver listado de profesores</a><br>
</div>
<div class="div4"><form method="post" action="creacion_profesores.php" method="POST">
            DNI PROFESOR <input type="text" name="dni"><br>
            NOMBRE <input type="text" name="nombre"><br>
            foto <input type ="text" name="apellido"><br>
            t_academico <input type ="text" name ="t_academico"><br>
            contrasenya <input type ="text"name ="contrasenya"><br>
            apellidos <input type ="text"name ="foto"><br>
            <input type="submit">
            </form> </div>
<div class="div5"> <a href="cerrar_sesion.php">Cerrar sesion</a></div>
<div class="div6"> COPYRIGHT CURSOS ESPAÑA</div></div> 
</div> 
            </body>
            </html>
            
    <?php
    //datos de la conexion a la base de datos
    }

	
    //aqui lo que hacemos es recoger los datos del usuario..
    //variable en la que guardamos la sentencia sql.
    //$SQL = "INSERT INTO CURSO (ID_CURSO,NOMBRE,DESCRIPCION,HORAS,F_INICIO,F_FINAL,PROFESOR) VALUES ('$ID_CURSO','$NOMBRE','$DESCRIPCION',$HORAS,'$F_INICIO','$F_FINAL','$PROFESOR')";
    //$PEPO =mysqli_query($CONEXION,$BUSCADOR);
}
//}else{
        echo ("No estás validado.");
//}
    ?>
    </body>
    </html>









