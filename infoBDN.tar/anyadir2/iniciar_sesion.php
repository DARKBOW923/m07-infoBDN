<?php
require 'functions/functions.php';
session_start();
if ($_POST){
        $user =$_POST['user'];
        $pass = $_POST['pass'];
        $con = conectar();
        $query_successful = iniciar_sesion($con, $user, $pass);
        if ($query_successful){
             $_SESSION['rol']=$user;
             $_SESSION['tipo'] = "alumno";
             echo "Bienvenido $user, serás redirigido en 3 segundos!";
             echo "<meta http-equiv='refresh' content='3;url=alumno/dashboard_alumno.php'>";
            }
        else{
            echo "usuario no encontrado o inexistente";
            echo $query_sucessful;
            echo "<meta http-equiv='refresh' content='3;url=../iniciar_sesion.php'>";
        }
        }else{
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/iniciar_sesion.css">
    <title>Document</title>
    </head>
    <body>
    <div class="parent">
    <div class="div1"> f</div>
    <div class="div2"> f</div>
    <div class="div3"> </div>
    <div class="div4"><form method="post" action ="iniciar_sesion.php">
        Usuario:<input type ="text" name="user">
        Contrasenya:<input type ="password" name="pass">
        <button action="submit">enviar</button>
    </form> </div>
    <div class="div5"> f</div>
    <div class="div6">f </div>
    </div> 
    </body>
    </html>

<?php
}
?>
