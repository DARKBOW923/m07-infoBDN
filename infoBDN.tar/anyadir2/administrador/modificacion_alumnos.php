<?php
require '../functions/functions.php';
session_start();
if(isset($_SESSION['rol']) && $_SESSION['tipo'] == "administrador"){
    $con = conectar();
    $buscar = seleccionar_alumnos($con);
    if ($_POST){
        $idAlumno = $_POST['id_alumno'];
        $nombre = $_POST['nombre'];
        $apellido = $_POST['apellido'];
        $foto = $_POST['foto'];
        //$foto = $_POST['foto'];
        $contrasenya = $_POST['contrasenya'];
        $modificar_alumno = modificar_alumnos($con,$nombre, $apellido, $contrasenya,$foto, $idAlumno);
        echo "<meta http-equiv='refresh' content='3;url=ver_alumnos.php'>";
    
    }
    else{
    ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <link rel="stylesheet" type="text/css" href="../css/prueba.css">

            <title>Document</title>
        </head>
        <body>
        <div class="parent">
<div class="div1"> </div>
<div class="div2"> <img src="../img/cursos.png" alt="Girl in a jacket">  </div>
<div class="div3"><nav>
    <a href="dashboard_administrador.php">Volver atras</a><br>
    <a href="creacion_cursos.php">Crear un curso</a><br>
    <a href="creacion_profesores.php">Crear un profesor</a><br>
    <a href="ver_alumnos.php">Ver listado de alumnos</a><br>
    <a href="ver_curso.php">Ver listado de cursos</a><br>
    <a href="ver_profesores.php">Ver listado de profesores</a><br>
</div>
<div class="div4">  <form method="post" action="modificacion_alumnos.php" method="POST">
            ID_ALUMNO <input type="text" name="id_alumno" value=<?php echo $buscar['ID_ALUMNO'];?>><br>
            DNI <input type="text" name="dni" value=<?php echo $buscar['DNI'];?>><br>
            NOMBRE <input type ="text" name="nombre"value=<?php echo $buscar['NOMBRE'];?>><br>
            APELLIDO <input type ="text" name ="apellido" value=<?php echo $buscar['APELLIDO'];?>><br>
            FOTO <input type ="text" name ="foto"value=<?php echo $buscar['FOTO'];?>><br>
            CONTRASENYA <input type="text" name="contrasenya"value=<?php echo $buscar['CONTRASENYA'];?>><br>
            ENVIAR <input type="submit"><br>
            </form></div>
<div class="div5"> <a href="cerrar_sesion.php">Cerrar sesion</a></div>
<div class="div6"> COPYRIGHT CURSOS ESPAÑA</div></div> 
            </body>
            </html>
 
    <?php
    }
}else{
        echo "Usuario no validado, redirigiengo a la página del login";
        echo "<meta http-equiv='refresh' content='3;url=admin.php'>";
 }   

?>



    










