<?php
require '../functions/functions.php';
session_start();
if(isset($_SESSION['rol']) && $_SESSION['tipo'] == "profesor"){
  
    if ($_POST){
        $con = conectar();
       
        $nota = $_POST['calificaciones'];
        $alumno = $_POST['id_alumno'];
        $curso = $_POST['id_curso'];
        echo $curso;
        echo $alumno;
        $poner_nota   = poner_calificaciones($con,$nota,$alumno,$curso);
        echo "nota puesta correctamente!";
        //$foto = $_POST['foto'];
       echo "<meta http-equiv='refresh' content='3;url=dashboard_profesor.php'>";
    }
    else{
        echo $curso =$_GET['ID_ALUMNO'];
        echo $alumno =$_GET['ID_CURSO'];

        //Recojo los valores de alumno curso
        //Dibujo un formulario solo para cambiar la nota
        //Envio el formulario a esta misma página 
    ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <link rel="stylesheet" type="text/css" href="../css/prueba.css">
            <title>Document</title>
        </head>
        <body>
        <?php
            $id_alumno= $_GET['ID_ALUMNO'];
            $id_curso= $_GET['ID_CURSO'];

        ?>
            <div class="parent">
<div class="div1"> </div>
<div class="div2"><img src="../img/cursos.png" alt="Girl in a jacket"></div>
<div class="div3"><nav>
    <a href="dashboard_profesor.php">Volver atras</a><br>
    
</div>
<div class="div4"> <form method="post" action="poner_calificaciones.php" method="POST">
            <!--//Dibuja un campo de ytecto para ponel la nueva nota
            //Enviar los datos con un campo oculto-->
           <!--
           <?php //echo $ver_profesor['CALIFICACIONES'];?>
    --> 
             Nueva nota<input type="number" min="0" max="10" name="calificaciones" required value="pon una nota"><br>
             <input type="hidden" name = "id_alumno"   value = "<?php echo $id_alumno?>">
             <input type="hidden" name = "id_curso"   value = "<?php echo $id_curso?>">
            EDITAR CAMPO(S) <input type="submit"><br>
        </form></div>
<div class="div5"> <a href="cerrar_sesion.php">Cerrar sesion</a></div>
<div class="div6"> </div>
</div>
            
        

            </body>
            </html>
            
    <?php
    }
}else{
        echo "Usuario no validado, redirigiengo a la página del login";
        echo "<meta http-equiv='refresh' content='3;url=admin.php'>";
 }   

?>
 