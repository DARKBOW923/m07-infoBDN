<?php
session_start();
require 'functions/functions.php';
    $con = conectar();
    if ($_POST){
        $usuario = $_POST['usuario'];
        $nombre = $_POST['nombre'];
        $apellido = $_POST['apellido'];
        $contrasenya = $_POST['contrasenya'];
        $foto = $_POST['foto'];
        $dni = $_POST['dni'];
        $_SESSION['tipo'] = 'alumno';
        $_SESSION['rol'] = $usuario;
       /* $FECHA_ACTUAL = date("d-m-Y");
        $FECHA_RESULTADO =  strtotime($FECHA_ACTUAL);
        $FECHA_DUMP_INICIO = strtotime($F_INICIO);
        $FECHA_DUMP_FINAL = strtotime($F_FINAL);*/
            echo "<meta http-equiv='refresh' content='3;url=alumno/dashboard_alumno.php'>";
            $registrarse = registrarse($con,$usuario,$dni,$nombre,$apellido,$foto,$contrasenya);
    }else{
    ?>
  <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <link rel="stylesheet" type="text/css" href="css/registrarse.css">
            <title>Document</title>
        </head>
        <body> <div class="parent">
<div class="div1"> </div>
<div class="div2">                 <div class="div2"><img src="../img/cursos.png" alt="Girl in a jacket"></div>
</div>
<div class="div3">  <form method="post" action="registrarse.php" method="POST">
            usuario <input type="text" name="usuario"><br>
            dni <input type ="text" name ="dni"><br>
            NOMBRE <input type="text" name="nombre"><br>
            apellido <input type ="text" name="apellido"><br>
            foto <input type ="text" name ="foto"><br>
            contrasenya <input type ="password" name ="contrasenya"><br>
            ENVIAR <input type="submit"><br>
            </form> </div>
<div class="div4"> </div>
<div class="div5"> </div>
</div> 
      
            </body>
            </html>
    <?php
    //datos de la conexion a la base de datos
    }
    ?>
    </body>
    </html>









