<?php
require '../functions/functions.php';
session_start();
if(isset($_SESSION['rol']) && $_SESSION['tipo'] == "administrador"){
    $con = conectar();
    $curso = seleccionar_curso($con);
    $profesores = desplegable_profesor($con);
    //echo $_GET['DNI'];
    date_default_timezone_set('Europe/Madrid');
   /* echo date("Y/m/d");
    echo $date;*/
    if ($_POST){
        $id_curso = $_POST['id_curso'];
        $nombre = $_POST['nombre'];
        $descripcion = $_POST['descripcion'];
        $profesor = $_POST['select1'];
        $horas = $_POST['horas'];
        $f_inicio = $_POST['f_inicio'];
        $f_final = $_POST['f_final'];
        //$foto = $_POST['foto'];
        $modificar_curso = modificar_curso($con,$id_curso,$nombre,$descripcion,$horas,$f_inicio,$f_final,$profesor);
       echo "<meta http-equiv='refresh' content='3;url=ver_curso.php'>";
    
    }
    else{
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" type="text/css" href="../css/prueba.css">
        
        <title>Document</title>
    </head>
    <div class="parent">
<div class="div1"> </div>
<div class="div2">  <img src="../img/cursos.png" alt="Girl in a jacket"> </div>
<div class="div3"><nav>
<a href="dashboard_administrador.php">Volver atras</a><br>
    <a href="creacion_cursos.php">Crear un curso</a><br>
    <a href="creacion_profesores.php">Crear un profesor</a><br>
    <a href="ver_alumnos.php">Ver listado de alumnos</a><br>
    <a href="ver_curso.php">Ver listado de cursos</a><br>
    <a href="ver_profesores.php">Ver listado de profesores</a><br>
</div>
<div class="div4">
<form class="centrar" method="post" action="modificacion_cursos.php" method="POST">
    ID_CURSO <input type="text" name="id_curso" readonly="readonly" value="<?php echo $curso['ID_CURSO'];?>"><br>    
    NOMBRE <input type ="text" name="nombre" value="<?php echo $curso['NOMBRE'];?>"><br>
    DESCRIPCION <input type="text"  name ="descripcion" value="<?php echo $curso['DESCRIPCION'];?>"><br> 
    HORAS <input type="text"  name="horas"value="<?php echo $curso['HORAS'];?>"><br> 
    F_INICIO <input type="date" min="<?php echo date('Y-m-d')?>" name="f_inicio" value="<?php echo $curso['F_INICIO'];?>"><br> 
    F_FINAL <input type="date" min="<?php echo date('Y-m-d')?>" name="f_final" value="<?php echo $curso['F_FINAL'];?>"><br> 
    PROFESOR ACTUAL (DNI)<input type="text" name="profesor2" readonly value="<?php echo $curso['PROFESOR'];?>"><br> 
    EDITAR CAMPO(S) <input type="submit"><br>
    PROFESOR: <select name="select1"  selected value="<?php echo $curso['PROFESOR'];?>">;
    <?php
       while ($row = mysqli_fetch_assoc($profesores)) {
        $object_dni = $row['DNI'];
        $object_nombre = $row['NOMBRE']. " ".$row['APELLIDOS'];

        echo "<option ";
        if($object_dni == $curso['PROFESOR'])
            echo 'selected ';
        echo "value='$object_dni'>{$object_nombre}</option>";
        }
?></select>

        </form> </div>
<div class="div5"> <a href="cerrar_sesion.php">Cerrar sesion</a></div>
<div class="div6"> COPYRIGHT CURSOS ESPAÑA</div></div> 
</body>
</html>

    <?php
    }
}else{
        echo "Usuario no validado, redirigiengo a la página del login";
        echo "<meta http-equiv='refresh' content='3;url=admin.php'>";
 }   

?>
 <?php
 /*
    while($fila=mysqli_fetch_array($ver_profesor)){
           echo "<option value='".$fila['NOMBRE']."'>".$fila['NOMBRE']."</option>";
        }
    echo "</select>"; ?><br>
    ?>*/