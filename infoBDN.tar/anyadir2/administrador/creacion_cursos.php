<?php
require '../functions/functions.php';
session_start();
if(isset($_SESSION['rol']) && $_SESSION['tipo'] == "administrador"){
    $con = conectar();
    $date = date('Y-m-d');
    echo $date;
    $profesores = desplegable_profesor($con);

    if ($_POST){
        $ID_CURSO =$_POST["id_curso"];
        $NOMBRE =$_POST["nombre"];
        $DESCRIPCION =$_POST["descripcion"];
        $HORAS =$_POST["horas"];
        $F_INICIO =$_POST["f_inicio"];
        $F_FINAL=$_POST["f_final"];
        $profesor=$_POST["profesor"];
       /* $FECHA_ACTUAL = date("d-m-Y");
        $FECHA_RESULTADO =  strtotime($FECHA_ACTUAL);
        $FECHA_DUMP_INICIO = strtotime($F_INICIO);
        $FECHA_DUMP_FINAL = strtotime($F_FINAL);*/
            echo "<meta http-equiv='refresh' content='3;url=dashboard_administrador.php'>";
            $crear_curso = crear_curso($con,$ID_CURSO,$NOMBRE,$DESCRIPCION,$HORAS,$F_INICIO,$F_FINAL,$profesor);
    
    }else{
    ?>      
            <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/prueba.css">
    <title>Document</title>
</head>
<body>
<div class="parent">
<div class="div1"> </div>
<div class="div2">  <img src="../img/cursos.png" alt="Girl in a jacket"> </div>
<div class="div3"><nav>
    <a href="dashboard_administrador.php">Volver atras</a><br>
    <a href="creacion_profesores.php">Crear un profesor</a><br>
    <a href="ver_alumnos.php">Ver listado de alumnos</a><br>
    <a href="ver_curso.php">Ver listado de cursos</a><br>
    <a href="ver_profesores.php">Ver listado de profesores</a><br>
    </nav>
</div>
<div class="div4"> <form method="post" action="creacion_cursos.php" method="POST">
            ID CURSO <input type="text" name="id_curso"><br>
            NOMBRE <input type="text" name="nombre"><br>
            DESCRIPCION <input type ="text" name="descripcion"><br>
            HORAS <input type ="text" name ="horas"><br>
            FECHA INICIO <input type ="date" min="<?php echo date('Y-m-d');?>"name ="f_inicio"><br>
            FECHA FINAL <input type="date" min="<?php echo date('Y-m-d');?>" name="f_final"><br>
            ENVIAR <input type="submit"><br>
            PROFESOR: <select name='profesor'  selected value="<?php echo $paco['NOMBRE'];?>">;
    <?php
       while ($row = mysqli_fetch_assoc($profesores)) {
        $object_dni = $row['DNI'];
        $object_nombre = $row['NOMBRE']. " ".$row['APELLIDOS'] ;

        echo "<option ";
        if($object_dni == $paco['PROFESOR'])
            echo 'selected ';
        echo "value='$object_dni'>{$object_nombre}</option>";
        }echo"</select>";
    ?></form></div>
<div class="div5"> <a href="cerrar_sesion.php">Cerrar sesion</a></div>
<div class="div6"> COPYRIGHT CURSOS ESPAÑA</div></div> 
</div> 
</body>
</html>
    
    <?php
    //datos de la conexion a la base de datos
    }

	
    //aqui lo que hacemos es recoger los datos del usuario..
    //variable en la que guardamos la sentencia sql.
    //$SQL = "INSERT INTO CURSO (ID_CURSO,NOMBRE,DESCRIPCION,HORAS,F_INICIO,F_FINAL,PROFESOR) VALUES ('$ID_CURSO','$NOMBRE','$DESCRIPCION',$HORAS,'$F_INICIO','$F_FINAL','$PROFESOR')";
    //$PEPO =mysqli_query($CONEXION,$BUSCADOR);
}
//}else{
        echo ("No estás validado.");
//}
    ?>
  








