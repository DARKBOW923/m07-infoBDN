<?php
require '../functions/functions.php';
session_start();
if(isset($_SESSION['rol']) && $_SESSION['tipo'] == "administrador"){
    echo $_SESSION['rol'];
$conexion = conectar();
$buscar =$_POST['buscar'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/prueba.css">
    <title>Document</title>
</head>
<body>
</body>
</html><div class="parent">
<div class="div1"> </div>
<div class="div2">  <img src="../img/cursos.png" alt="Girl in a jacket"> </div>
<div class="div3"><nav>
    <a href="dashboard_administrador.php">Volver atras</a><br>
    <a href="creacion_cursos.php">Crear un curso</a><br>
    <a href="creacion_profesores.php">Crear un profesor</a><br>
    <a href="ver_curso.php">Ver listado de cursos</a><br>
    <a href="ver_profesores.php">Ver listado de profesores</a><br>
</div>
<div class="div4"> <form name ="busqueda" method="post">buscar <input type="text" name="buscar">
           ENVIAR <input type="submit"><?php $llamada = ver_alumnos($conexion,$buscar);?>Reiniciar buscador <input type="submit">
</div>
<div class="div5"> <a href="cerrar_sesion.php">Cerrar sesion</a></div>
<div class="div6"> COPYRIGHT CURSOS ESPAÑA</div>










<?php
}else{
    echo "no estas validado!";
}
 ?>
    <!--
       
</form>
   <?php 
    /*
    $BUSCADOR = "SELECT * FROM ALUMNOS WHERE ALUMNOS.ID_ALUMNO LIKE '%$BUSCAR%' AND DESACTIVAR = 'no'";
//$PEPO =mysqli_query($CONEXION,$BUSCADOR);
$PEPO =mysqli_query($CONEXION,$BUSCADOR);
echo '<table border = 1px solid black>';
echo '

    <th>ID_ALUMNO</th>
    <th> DNI</th>
    <th>NOMBRE</th> 
    <th> APELLIDO </th> 
    <th> FOTO</th>
    <th> CONTRASENYA </th>

';
    
        
        while ( $fila = mysqli_fetch_array($PEPO) ) {
       echo '
            <tr>  
                <td>' . $fila['ID_ALUMNO'].'</td>
                <td>' . $fila['DNI'] . '</td>
                <td>' . $fila['NOMBRE'] . '</td>
                <td>' . $fila['APELLIDO']. '</td>
                <td>' . $fila['FOTO']. '</td>
                <td>' . $fila['CONTRASENYA'] . '</td>
                <td><a href="editar_alumnos.php?ID_ALUMNO='.$fila['ID_ALUMNO']. '">editar</a></td>
                <td><a href="eliminar_alumnos.php?ID_ALUMNO='.$fila['ID_ALUMNO']. '">eliminar</a></td>
                
            </tr>';
            
        }
        echo '</table>';
      
    
  
   
    ?>
    </div>
    <div class="div6"><a href="cerrar_sesion.php">Cerrar sesión</a></div> 
    </div>
</body>
</html>  
<?php
//aqui lo que hacemos es recoger los datos del usuario..
//variable en la que guardamos la sentencia sql.
?>
*/
