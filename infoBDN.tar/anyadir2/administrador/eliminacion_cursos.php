<?php
require '../functions/functions.php';
session_start();
if(isset($_SESSION['rol']) && $_SESSION['tipo'] == "administrador"){
    echo $_SESSION['rol'];
    $con = conectar();
    $curso = $_GET['ID_CURSO'];
    $eliminar_curso = eliminar_curso($con,$curso);
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
    </head>
    <body>
        <p>Curso eliminado con exito!</p>
        <meta http-equiv='refresh' content='3;url=ver_curso.php'>

    </body>
    </html>
<?php
}else{
    echo "no validado! redirigiendo en pocos segundos..";
    echo "<meta http-equiv='refresh' content='3;url=admin.php'>";
}
?>