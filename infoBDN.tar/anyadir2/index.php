<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <title>Document</title>
</head>
<body>
<div class="container">
  <div class="Header"><img src="img/cursos.png" alt="logo" width="1575" height="300"></div>
  <div class="Footer"></div>
  <div class="Body"></div>
  <div class="Iniciar-sesion"><a href="iniciar_sesion.php">Iniciar sesion</a></div>
  <div class="Registrarse"><a href="registrarse.php">Registrarse</a></div>
  <div class="Chica"><img src="img/chica.jpeg" alt="chica"width="400" height="200"><p class="color">"Gracias a cursos españa, pude aprobar php"</p></div>
  <div class="Curso"><img src="img/curso.jpeg" alt="curso"width="400" height="200"><p class="color">"Cursos españa me ayudó a aprobar javascript"</p></div>
  <div class="Footer2">COPYRIGHT CURSOS ESPANYA</div>
</div>


</body>
</html>