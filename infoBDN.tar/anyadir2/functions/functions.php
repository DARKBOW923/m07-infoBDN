<?php
function conectar(){
  $servidor = "192.168.1.42";
  $usuario = "root2";
  $contrasenya = "1234";
  $bbdd = "infoBDN";
  $con = mysqli_connect($servidor,"root2","1234","infoBDN");    
  return $con;
}
function iniciar_sesion_administrador($con,$user,$pass){
    $sql = "SELECT * FROM ADMINISTRADOR WHERE USUARIO = '{$user}' AND CONTRASENYA = '".md5($pass)."'";
    $query =mysqli_query($con,$sql);
    $result = mysqli_num_rows ( $query );
    return $result;
}
function iniciar_sesion($con,$user,$pass){
   $sql = "SELECT * FROM ALUMNOS WHERE ID_ALUMNO = $user AND CONTRASENYA = '".md5($pass)."'";
   $query = mysqli_query($con,$sql);
   $result =mysqli_num_rows ($query);
   return $result;
}
function ver_alumnos($con,$buscar){
$query = "SELECT * FROM ALUMNOS WHERE DESACTIVAR ='no' AND NOMBRE LIKE '%$buscar%'";
//echo $resultado;
$PEPO =mysqli_query($con,$query);
echo '<table class ="centrar" border = 1px solid black>';
echo '

    <th>ID_ALUMNO</th>
    <th> DNI</th>
    <th>NOMBRE</th> 
    <th> APELLIDO </th> 
    <th> FOTO</th>
    <th> CONTRASENYA </th>

';
    
        
        while ( $fila = mysqli_fetch_array($PEPO) ) {
       echo '
            <tr>  
                <td>' . $fila['ID_ALUMNO'].'</td>
                <td>' . $fila['DNI'] . '</td>
                <td>' . $fila['NOMBRE'] . '</td>
                <td>' . $fila['APELLIDO']. '</td>
                <td>' . $fila['FOTO']. '</td>
                <td>' . $fila['CONTRASENYA'] . '</td>
                <td><a href="../administrador/modificacion_alumnos.php?ID_ALUMNO='.$fila['ID_ALUMNO']. '">editar</a></td>
                <td><a href="../administrador/eliminacion_alumnos.php?ID_ALUMNO='.$fila['ID_ALUMNO']. '">eliminar</a></td>
                
            </tr>';
            
        }
        echo '</table>';

}
function borrar_alumno($con, $idAlumno){
$query_borrar = "UPDATE ALUMNOS SET DESACTIVAR = 'SI' WHERE ID_ALUMNO = $idAlumno";
$resultado = mysqli_query($con,$query_borrar);
//$borrar = mysqli_query($con,$seleccionar);
}
function modificar_alumnos($con,$nombre,$apellido,$contrasenya,$foto,$idAlumno){
    $query_modificar = "UPDATE ALUMNOS SET NOMBRE = '$nombre', APELLIDO = '$apellido', CONTRASENYA ='$contrasenya', FOTO ='$foto' WHERE ID_ALUMNO = $idAlumno";
    echo $query_modificar;
    $resultado = mysqli_query($con,$query_modificar);
    //return $resultado;
}
function seleccionar_alumnos($con){
    $seleccionar = "SELECT * FROM ALUMNOS WHERE ID_ALUMNO = '".$_GET['ID_ALUMNO']."'";
    $result = mysqli_query($con,$seleccionar);
    $resultado = mysqli_fetch_assoc($result);
    echo $resultado['CONTRASENYA'];
    return $resultado;
}
function ver_curso($con,$buscar){
   $query = "SELECT * FROM CURSO WHERE NOMBRE LIKE '%$buscar%'";
         $PEPO =mysqli_query($con,$query);
         echo '<table class="centrar" border = 1px solid black>';
         echo '
         
             <th>ID_CURSO</th>
             <th> NOMBRE</th>
             <th>DESCRIPCION</th> 
             <th> HORAS </th> 
             <th> F_INICIO</th>
             <th> F_FINAL </th>
             <th> PROFESOR</th>
             <th> EDITAR</th>
             <th> ELIMINAR</th>
         
         ';
             
                 
                 while ( $fila = mysqli_fetch_array($PEPO) ) {
                echo '
                     <tr>  
                         <td>' . $fila['ID_CURSO'].'</td>
                         <td>' . $fila['NOMBRE'] . '</td>
                         <td>' . $fila['DESCRIPCION'] . '</td>
                         <td>' . $fila['HORAS']. '</td>
                         <td>' . $fila['F_INICIO']. '</td>
                         <td>' . $fila['F_FINAL'] . '</td>
                         <td>' . $fila['PROFESOR']. '</td>
                         <td><a href="modificacion_cursos.php?ID_CURSO='.$fila['ID_CURSO']. '">editar</a></td>
                         <td><a href="eliminacion_cursos.php?ID_CURSO='.$fila['ID_CURSO']. '">eliminar</a></td>
                         
                     </tr>';
                     
                 }
                 echo '</table>';
                 

}
function seleccionar_curso($con){
    $seleccionar = "SELECT * FROM CURSO WHERE ID_CURSO = '".$_GET['ID_CURSO']."'";
    $result = mysqli_query($con,$seleccionar);
    $resultado = mysqli_fetch_assoc($result);
    echo $resultado['NOMBRE'];
    return $resultado;  
}

function modificar_curso($con,$id_curso,$nombre,$descripcion,$horas,$f_inicio,$f_final,$profesor){
    date_default_timezone_set('Europe/Madrid');

// Then call the date functions
$date = date('d-m-y');
//echo $date;
$fecha = strtotime($date);
echo $fecha;
    /*date_default_timezone_set('Europe/Madrid');
            $fecha = date('d-m-y')."\n";
            echo $fecha;*/
    if ($f_inicio > $f_final){
        echo "error: la fecha final NO puede ser menor que la fecha de inicio";
    }else if ($f_inicio < $f_final){
    $query_modificar = "UPDATE CURSO SET NOMBRE = '$nombre', DESCRIPCION = '$descripcion', HORAS =$horas, F_INICIO = '{$f_inicio}', F_FINAL = '{$f_final}', PROFESOR ='{$profesor}' WHERE ID_CURSO = $id_curso";
    echo $query_modificar;
    $resultado = mysqli_query($con,$query_modificar);
    }
}
function desplegable_profesor($con){
    $seleccionar = "SELECT * FROM PROFESOR WHERE DESACTIVAR = 'no'";
    echo $_GET['DNI'];
    $result = mysqli_query($con,$seleccionar);
    //$fetch = mysqli_fetch_assoc($result);
    echo $resultado['DNI'];
    return $result;
}
function ver_profesores($con,$dni){
    $seleccionar = "SELECT * FROM PROFESOR WHERE DESACTIVAR = 'no' AND DNI = '{$dni}'";
    echo $_GET['DNI'];
    $result = mysqli_query($con,$seleccionar);
    $fetch = mysqli_fetch_assoc($result);
    echo $resultado['DNI'];
    return $fetch;
}
function ver_profesor($con,$buscar){
    $query = "SELECT * FROM PROFESOR WHERE DESACTIVAR = 'no' AND NOMBRE LIKE '%$buscar%'";
          $PEPO =mysqli_query($con,$query);
          echo '<table class="centrar" border = 1px solid black>';
          echo '
          
              <th>DNI</th>
              <th> APELLIDOS</th>
              <th>T_ACADEMICO</th> 
              <th>FOTO</th> 
              <th> CONTRASENYA </th> 
              <th> NOMBRE </th>
              <th> DESACTIVAR</th>
          
          ';
              
                  
                  while ( $fila = mysqli_fetch_array($PEPO) ) {
                 echo '
                      <tr>  
                          <td>' . $fila['DNI'].'</td>
                          <td>' . $fila['APELLIDOS'] . '</td>
                          <td>' . $fila['T_ACADEMICO'] . '</td>
                          <td>' . $fila['FOTO']. '</td>
                          <td>' . $fila['CONTRASENYA']. '</td>
                          <td>' . $fila['NOMBRE'] . '</td>
                          <td>' . $fila['DESACTIVAR']. '</td>
                          <td><a href="modificacion_profesores.php?DNI='.$fila['DNI']. '">editar</a></td>
                          <td><a href="eliminacion_profesores.php?DNI='.$fila['DNI']. '">eliminar</a></td>
                      </tr>';
                      
                  }
                  echo '</table>';
                  
 
 }
 function eliminar_profesor($con,$dni){
    $query = "UPDATE PROFESOR SET DESACTIVAR = 'si' WHERE DNI = '{$dni}'";
    $resultado = mysqli_query($con,$query);
 }
 function modificar_profesor($con,$nombre,$apellido,$t_academico,$contrasenya,$dni){
    $query = "UPDATE PROFESOR SET NOMBRE = '$nombre', APELLIDOS = '$apellido', T_ACADEMICO = '$t_academico', CONTRASENYA = md5('$contrasenya') WHERE DNI = '$dni'";
    $resultado = mysqli_query($con,$query);
    echo $resultado;
 }
 function crear_curso($con,$id_curso,$nombre,$descripcion,$horas,$f_inicio,$f_final,$profesor){
   if ($f_final > $f_inicio){
    $SQL = "INSERT INTO CURSO (ID_CURSO,NOMBRE,DESCRIPCION,HORAS,F_INICIO,F_FINAL,PROFESOR) VALUES ('$id_curso','$nombre','$descripcion',$horas,'$f_inicio','$f_final','$profesor')";
    $resultado = mysqli_query($con,$SQL);
    echo $SQL;
    echo "Curso añadido! Serás redirigido en 3 segundos..";
    echo $resultado;
   }else{
    echo "Error, no se ha anyadido el curso!";
   }
 }
 function registrarse($con,$usuario,$dni,$nombre,$apellido,$foto,$contrasenya){
    $pattern = '/^[0-9]{8,8}[TRWAGMYFPDXBNJZSQVHLCKE]$/';
  if (preg_match_all($pattern,$dni)){
    $sql = "INSERT INTO ALUMNOS VALUES ($con,$usuario,'{$dni}','{$nombre}','{$apellido}','{$foto}',md5('{$contrasenya}','no')";
    $resultado = mysqli_query($con,$sql);
  }else{
    echo ("DNI NO VALIDO!");
    echo $SQL;
  }

 }
 function dashboard_alumno($con,$buscar,$usuario){
    $BUSCADOR ="SELECT DISTINCT MATRICULA.ID_ALUMNO,MATRICULA.ID_CURSO,CURSO.NOMBRE,CURSO.DESCRIPCION,CURSO.HORAS,CURSO.F_INICIO,CURSO.F_FINAL,MATRICULA.CALIFICACIONES FROM ALUMNOS,MATRICULA,CURSO WHERE MATRICULA.ID_ALUMNO =$usuario AND CURSO.ID_CURSO = MATRICULA.ID_CURSO and CURSO.NOMBRE LIKE '%$buscar%'";
    $PEPO =mysqli_query($con,$BUSCADOR);
    echo '<table class= "centrar" border = 1px solid black>';
    echo '
    
        <th> NOMBRE</th>
        <th> HORAS </th> 
        <th> F_INICIO</th>
        <th> F_FINAL </th>
        <th> NOTA</th>
        <th> BORRARSE</th>
    
    ';
        
            
            while ( $fila = mysqli_fetch_array($PEPO) ) {
           echo '
                <tr>  
                    <td>' . $fila['NOMBRE'] . '</td>
                    <td>' . $fila['HORAS'] . '</td>
                    <td>' . $fila['F_INICIO']. '</td>
                    <td>' . $fila['F_FINAL']. '</td>
                    <td>' . $fila['CALIFICACIONES']. '</td>
                    <td><a href="baja_cursos.php?ID_CURSO='.$fila['ID_CURSO'].'">borrarse</a></td>
                </tr>';
                
            }
            echo '</table>';
 }
 function darse_baja($con,$usuario){
    $query = "DELETE FROM MATRICULA WHERE MATRICULA.ID_CURSO = $usuario";
    $resultado = mysqli_query($con,$query);
    echo $resultado;
 }
 function ver_cursos_disponibles($con,$buscador,$usuario){
    //query = "SELECT * FROM CURSO";
    $query = "SELECT * FROM CURSO WHERE CURSO.ID_CURSO NOT IN (SELECT MATRICULA.ID_CURSO FROM MATRICULA WHERE MATRICULA.ID_ALUMNO = $usuario) AND NOMBRE LIKE '%$buscador%'";
          $PEPO =mysqli_query($con,$query);
          echo '<table class="centrar" border = 1px solid black>';
          echo '
          
              <th>ID_CURSO</th>
              <th> NOMBRE</th>
              <th>DESCRIPCION</th> 
              <th> HORAS </th> 
              <th> F_INICIO</th>
              <th> F_FINAL </th>
              <th> PROFESOR</th>
              <th> EDITAR</th>
          
          ';
              
                  
                  while ( $fila = mysqli_fetch_array($PEPO) ) {
                 echo '
                      <tr>  
                          <td>' . $fila['ID_CURSO'].'</td>
                          <td>' . $fila['NOMBRE'] . '</td>
                          <td>' . $fila['DESCRIPCION'] . '</td>
                          <td>' . $fila['HORAS']. '</td>
                          <td>' . $fila['F_INICIO']. '</td>
                          <td>' . $fila['F_FINAL'] . '</td>
                          <td>' . $fila['PROFESOR']. '</td>
                          <td><a href="alta_cursos.php?ID_CURSO='.$fila['ID_CURSO']. '">Apuntarse</a></td>
                      </tr>';
                  }
                  echo '</table>';
                  
 
 }
 function apuntarse($con,$usuario,$id_curso){
    $query = "INSERT INTO MATRICULA (ID_ALUMNO,ID_CURSO,CALIFICACIONES) VALUES ($usuario,'$id_curso','0')";
    $resultado = mysqli_query($con,$query);
    echo $resultado;
 }
 function eliminar_curso($con,$curso){
    $sql = "DELETE FROM CURSO WHERE ID_CURSO = $curso";
    mysqli_query($con,$sql);
 }
 function dashboard_profesor($con,$usuario){
    echo $usuario;
    $query = "SELECT DISTINCT PROFESOR.DNI,CURSO.PROFESOR,CURSO.ID_CURSO,MATRICULA.ID_CURSO,ALUMNOS.ID_ALUMNO,CURSO.NOMBRE,MATRICULA.CALIFICACIONES,CURSO.F_INICIO,CURSO.F_FINAL,CURSO.HORAS FROM ALUMNOS,CURSO,MATRICULA,PROFESOR WHERE PROFESOR.DNI = '{$usuario}' AND CURSO.PROFESOR = '{$usuario}' AND CURSO.ID_CURSO = MATRICULA.ID_CURSO AND ALUMNOS.ID_ALUMNO = MATRICULA.ID_ALUMNO AND ALUMNOS.DESACTIVAR ='si'";
    //$query = "SELECT * FROM CURSO WHERE CURSO.PROFESOR = '{$usuario}'";
    //$BUSCADOR ="SELECT  PROFESOR.DNI, CURSO.PROFESOR,CURSO.ID_CURSO,MATRICULA.ID_CURSO,ALUMNOS.ID_ALUMNO,CURSO.NOMBRE,MATRICULA.CALIFICACIONES,CURSO.F_INICIO,CURSO.F_FINAL,CURSO.HORAS FROM ALUMNOS,PROFESOR,CURSO,MATRICULA WHERE PROFESOR.DNI = '{$USUARIO2}' AND CURSO.PROFESOR = '{$USUARIO2}' AND CURSO.ID_CURSO = MATRICULA.ID_CURSO AND ALUMNOS.ID_ALUMNO = MATRICULA.ID_ALUMNO  AND ALUMNOS.DESACTIVAR = 'no' AND ALUMNOS.ID_ALUMNO LIKE '%$buscar%'";
    $PEPO = mysqli_query($con,$query);
    echo '<table class="centrar" border = 1px solid black>';
echo '

    <th>ID_ALUMNO</th>
    <th> NOMBRE</th>
    <th>ID_CURSO</th> 
    <th> HORAS </th> 
    <th> F_INICIO</th>
    <th> F_FINAL </th>
    <th> CALIFICACIONES</th>

';
    
        
        while ( $fila = mysqli_fetch_array($PEPO) ) {
       echo '
            <tr>  
                <td>' . $fila['ID_ALUMNO'] . '</td>
                <td>' . $fila['NOMBRE'] . '</td>
                <td>' . $fila['ID_CURSO'] . '</td>
                <td>' . $fila['HORAS'] . '</td>
                <td>' . $fila['F_INICIO']. '</td>
                <td>' . $fila['F_FINAL']. '</td>
                <td>' . $fila['CALIFICACIONES']. '</td>
                <td><a href="poner_calificaciones.php?ID_ALUMNO='.$fila['ID_ALUMNO'].'&ID_CURSO='.$fila['ID_CURSO'].'">PONER NOTA</a></td>
                
            </tr>';
        }
        echo '</table>';
        
 }
 function iniciar_sesion_profesor($con,$user,$pass){
    $sql = "SELECT * FROM PROFESOR WHERE DNI = '{$user}' AND CONTRASENYA = '".md5($pass)."'";
    $query =mysqli_query($con,$sql);
    $result = mysqli_num_rows ( $query );
    return $result;
 }
 function poner_calificaciones($con,$calificacion,$id_alumno,$id_curso){
    $query = "UPDATE MATRICULA SET CALIFICACIONES = $calificacion WHERE MATRICULA.ID_ALUMNO = $id_alumno AND MATRICULA.ID_CURSO = $id_curso";
    $resultado = mysqli_query($con,$query);
 }
 function prueba($con,$id_curso,$id_alumno){
    $query = "SELECT ALUMNOS.ID_ALUMNO,CURSO.ID_CURSO FROM CURSO,ALUMNOS WHERE ALUMNOS.ID_ALUMNO = $id_alumno AND CURSO.ID_CURSO = $id_curso";
    //$query = "SELECT ALUMNOS.ID_ALUMNO,CURSO.NOMBRE,CURSO.ID_CURSO,CURSO.HORAS,CURSO.F_FINAL,CURSO.F_INICIO,MATRICULA.CALIFICACIONES FROM ALUMNOS,CURSO,MATRICULA WHERE ALUMNOS.ID_ALUMNO = $pepe";
    //$query= "SELECT MATRICULA.ID_CURSO,MATRICULA.ID_ALUMNO,CURSO.NOMBRE,ALUMNOS.ID_ALUMNO,CURSO.F_INICIO,CURSO.F_FINAL,CURSO.ID_CURSO,CURSO.HORAS FROM MATRICULA,ALUMNOS,CURSO WHERE ALUMNOS.ID_ALUMNO = $pepe";
    //$query = "SELECT CURSO.F_INICIO,CURSO.F_FINAL,ALUMNOS.ID_ALUMNO,CURSO.NOMBRE,CURSO.HORAS,MATRICULA.CALIFICACIONES FROM CURSO,ALUMNOS,MATRICULA WHERE CURSO.ID_CURSO = MATRICULA.ID_CURSO";
    $resultado = mysqli_query($con,$query);
    $resultado2 = mysqli_fetch_assoc($resultado);
    return $resultado2;
 }
 function creacion_profesor($con,$dni,$t_academico,$nombre,$apellido,$contrasenya,$foto){
    $pattern = '/^[0-9]{8,8}[TRWAGMYFPDXBNJZSQVHLCKE]$/';
  if (preg_match_all($pattern,$dni)){
    $query = "INSERT INTO PROFESOR (DNI,APELLIDOS,T_ACADEMICO,FOTO,CONTRASENYA,NOMBRE,DESACTIVAR) VALUES ('$dni','$apellido','$t_academico','$foto',md5('$contrasenya'),'$nombre', 'no')";
    $resultado = mysqli_query($con,$query);
  }else{
    echo ("DNI NO VALIDO!");
    echo $SQL;
  }
   
 }
?>